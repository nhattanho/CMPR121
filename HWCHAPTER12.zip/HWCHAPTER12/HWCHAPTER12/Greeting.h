#pragma once
// Header file for display 12_5
#ifndef GREETING_H 
#define GREETING_H

#include <iostream>
using namespace std;

namespace savitch1
{
	void greeting();
}

namespace savitch2
{
	void greeting();
}

void bigGreeting();

#endif
